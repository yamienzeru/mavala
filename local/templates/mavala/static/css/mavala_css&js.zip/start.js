function equalHeight(group, groupSize) {
	if (!group.length) {
		return;
	}
	groupSize = +(groupSize || 0);
	if (groupSize < 1) {
		groupSize = group.length;
	}
	var start = -groupSize, part;
	while ((part = group.slice(start += groupSize, start + groupSize)) && part.length) {
		part.height(Math.max.apply(null, $.makeArray(part.map(function () {
			return $(this).height();
		}))));
	}
}
jQuery(function ($) {

	function attachFancybox(parent)
	{
		parent = parent || $('body');
		parent.find('.btn-popup').fancybox({
			padding: 0,
			afterShow: function () {
				prepareFancyboxContent(this);
			}
		});

		parent.find('.btn-popup2').fancybox({
			padding: 0,
			fitToView: false,
			afterShow: function () {
				prepareFancyboxContent(this);
			}
		});
	}

	function prepareFancyboxContent(fancybox) {
		$('#subscribe-two').validate({
			submitHandler: function (form) {
				$.fancybox.open({href: $(form).attr('action'), type: 'ajax', padding: 0,
					afterShow: function () {
						prepareFancyboxContent(this);
					}
				})
			}
		});

		attachFancybox($(fancybox.inner));

		$("#loginform").validate();
		$('#email-repair').validate({
			submitHandler: function (form) {
				$.fancybox.open({href: $(form).attr('action'), type: 'ajax', padding: 0, afterShow: function () {
					prepareFancyboxContent(this);
				}});
			}
		});

		$(".popup .wrap-input input[type=checkbox]").Custom({
			customStyleClass: 'checkbox',
			customHeight: '17',
			enableHover: true
		});

		var slides = $('.deliver-and-pay .right-side .item');
		var navigation = $('.deliver-and-pay nav a').on('click', function (e) {
			$('.deliver-and-pay nav a').removeClass('active');
			var $this = $(this);
			$this.addClass('active');
			e.preventDefault();
			$('.fancybox-overlay').scrollTo((slides.eq($this.index())), 1000);
		});
		var box = $('.deliver-and-pay nav');
		var boxHeight = box.height();
		$('.fancybox-overlay').on('scroll', function () {
			var top = $('.fancybox-overlay').scrollTop();
			slides.each(function () {
				var el = $(this);
				if (el.position().top > top - 350) {
					navigation.removeClass('active').eq(el.index()).addClass('active');
					return false;
				}
			});
			top += 20;
			if (top + boxHeight > $(fancybox.inner).children().height()) {
				top = $(fancybox.inner).children().height() - boxHeight;
			} else {
				if (top < 211) {
					top = 211;
				}
			}
			box.css('top', top);
		});
	}

	$('.amount-block .btn-min').on('click', function (e) {
		e.preventDefault();
		var count = $(this).closest('.amount-block').find('input');
		if (count.val() > 0) {
			count.val(parseInt(count.val()) - 1);
		}
	});
	$('.amount-block .btn-max').on('click', function (e) {
		e.preventDefault();
		var count = $(this).closest('.amount-block').find('input');
		count.val(parseInt(count.val()) + 1);
	});

	$('.head-cling').hide();

	$(window).scroll(function () {
		if ($(this).scrollTop() > 200) {
			$('.head-cling').fadeIn();
		} else {
			$('.head-cling').fadeOut();
		}
	});
	attachFancybox();

	function format(state) {
		if (!state.id) return state.text; // optgroup
		return "<span class='color-row' style='background-color:#" + state.id.toLowerCase() + "'></span>";
	}

	$('select.color').select2({
		dropdownCssClass: 'colorlist',
		formatResult: format,
		formatSelection: format,
		escapeMarkup: function (m) {
			return m;
		}
	});

	$('select.sort').select2({
		dropdownCssClass: 'sortlist'
	});
	$('select.sort.number').select2({
		dropdownCssClass: 'sortlist'
	});

	$('.product-list-top .choose').on('click', function () {
		$('.sort .drop-list').slideUp();
		$(this).closest('.sort').find('.drop-list').slideDown();
	});

	$('.property.volume-block select').select2({
		dropdownCssClass: 'volumelist'
	}).on("select2-open", function() {
		$(document).off('mouseleave.elementhover');
		$(document).off('mouseenter.elementhover');
	}).on("select2-close", function() {
		$(document).on('mouseenter.elementhover', '.slider-catalog ul li', function(){
			$(this).addClass('active');
		}).on('mouseleave.elementhover', '.slider-catalog ul li', function(){
			$(this).removeClass('active');
		});

		$(document).on('mouseenter.elementhover', '.wrap-product', function(){
			$(this).addClass('active');
		}).on('mouseleave.elementhover', '.wrap-product', function(){
			$(this).removeClass('active');
		});
	});

	$('.social-likes').socialLikes({
		url: 'https://github.com/sapegin/social-likes/',
		title: 'Beautiful “like” buttons with counters for popular social networks',
		counters: true,
		singleTitle: 'Share it!'
	});

	equalHeight($('.product-table .wrap-product'));
	equalHeight($('.slider-catalog ul li'));

	$('.slider-main').removeClass('hide-block');

	$(window).resize(function () {
		$('.slider-main .top-line, .slider-main .bottom-line').width($(window).width() - 10);
		$('.slider-main .right-line,.slider-main .left-line').height($(window).height() - 69);
		$('.slider-action ul[data-type="down"]').width($(window).width()/2);
	}).resize();

	$(".img-background").each(function () {
		var el = $(this);
		el.closest('li').css('background-image', 'url(' + el.attr('src') + ')');
	});

	$(window).load(function () {

		$('.slider-main > ul').carouFredSel({
			items: 1,
			auto: true,
			onCreate: function () {
				$('.slider-main ul li').eq(0).addClass('active');
			},
			scroll: {
				timeoutDuration: 8000,
				fx: 'slide',
				onAfter: function (data) {
					$('.slider-main ul li').removeClass('active');
					data.items.visible.addClass('active');
				}
			},
			swipe:{
				onTouch:true
			},
			responsive: true,
			prev: {
				button: ".slider-main  .btn-left",
				key: "left"
			},
			next: {
				button: ".slider-main  .btn-right",
				key: "right"
			},
			pagination: $('.slider-main .control')
		});

		$('.slider-action > ul').each(function () {
			var el = $(this);
			if (el.attr('data-type') == 'up' || el.attr('data-type') == 'down') {
				el.carouFredSel({
					items: 1,
					auto: true,
					direction: el.attr('data-type'),
					scroll: {
						timeoutDuration: 8000,
						fx: 'slide'
					},
					pagination: function () {
						return $(this).closest('.slider-action').find('.control')
					}
				});
			} else {
				el.carouFredSel({
					items: 1,
					auto: true,
					direction: el.attr('data-type'),
					scroll: {
						timeoutDuration: 8000,
						fx: 'slide'
					},
					responsive: true,
					pagination: function () {
						return $(this).closest('.slider-action').find('.control')
					}
				});
			}
		});

		$('.slider-specific > ul').carouFredSel({
			items: 1,
			auto: true,
			scroll: {
				timeoutDuration: 8000,
				fx: 'slide'
			},
			swipe:{
				onTouch:true
			},
			responsive: true,
			pagination: $('.slider-specific .control-disk'),
			prev: {
				key: 'left',
				button: ".slider-specific .btn-prev"
			},
			next: {
				key: 'right',
				button: ".slider-specific .btn-next"
			}
		});

		$('.promo-banner > ul').carouFredSel({
			items: 1,
			auto: true,
			swipe:{
				onTouch:true
			},
			scroll: {
				fx: 'slide',
				timeoutDuration: 8000
			},
			pagination: function () {
				return $(this).closest('.promo-banner').find('.control-disk')
			}
		});

		$('.slider-catalog > ul').carouFredSel({
			auto: true,
			items: 'variable',
			scroll: {
				items: 1,
				pauseOnHover: true,
				timeoutDuration: 8000
			},
			swipe:{
				onTouch:true
			},
			prev: {
				button: function () {
					return $(this).closest('.slider-catalog').find('.btn-prev');
				}
			},
			next: {
				button: function () {
					return $(this).closest('.slider-catalog').find('.btn-next');
				}
			},
			pagination: function () {
				return $(this).closest('.slider-catalog').find('.control-disk');
			}
		});
	});

	/*rotation carousel size fix*/
	var doit;

	function resizedw() {
		$('.slider-main li').height($(window).height());
		$(".slider-catalog > ul, .slider-main > ul, .slider-action > ul, .slider-specific > ul, .promo-banner > ul").each(function () {
			$(this).trigger('updateSizes').trigger('configuration', ['debug', false, true]);
		});
	}

	$(window).resize(function () {
		clearTimeout(doit);
		doit = setTimeout(function () {
			resizedw();
		}, 500);
	});

	if (window.addEventListener) {
		window.addEventListener("orientationchange", function () {
			clearTimeout(doit);
			doit = setTimeout(function () {
				resizedw();
			}, 500);
		}, false);
	}

	$('.contact-info .city').on('click', function (e) {
		e.preventDefault();
		$('header').toggleClass('header-lvl');
		$('.instruction-city .sub-item').css('display', 'none');
		$('.instruction-city').stop(true, true).fadeToggle(function () {
			$('.instruction-city .sub-item:first').stop(true, true).fadeIn();
		});
	});

	$('.instruction-city .no').on('click', function (e) {
		e.preventDefault();
		$('header').removeClass('header-lvl');
		$('.instruction-city').stop(true, true).fadeOut();
		$('.instruction-city .sub-item').removeClass('active');
	});
	$('.instruction-city .yes').on('click', function (e) {
		e.preventDefault();
		$(this).parent().stop(true, true).fadeOut(function () {
			$(this).removeClass('active');
			$('.instruction-city .sub-item:nth-child(2)').stop(true, true).fadeIn(function () {
				$(this).addClass('active');
			});
		});
	});
	$('.acc-management .search').on('click', function (e) {
		e.preventDefault();
		$('.header-top .search-block').slideDown();
	});

	$(window).resize(
		function () {
			var heightWindow = $(window).height();
			$('header.main-page').height(heightWindow);
		}
	).resize();


	$('.section2 .btn-more2').on('click', function (e) {
		e.preventDefault();
		$(this).toggleClass('active');
		$('.section2 .drop').slideToggle();

	});
	$('.header-catalog .text-block  .btn-more2').on('click', function (e) {
		e.preventDefault();
		$(this).toggleClass('active');
		$('.header-catalog .text-block .drop').slideToggle();
	});

	$('.filters .filter-title').on('click', function (e) {
		e.preventDefault();
		$(this).closest('.item').toggleClass('active');
		$(this).closest('.item').find('.drop').slideToggle();
	});
	$('.remove-filter').on('click', function (e) {
		e.preventDefault();
		$('.menu.filters .item').removeClass('active');
		$('.menu.filters .drop').slideUp();
	});

	if($('.slider-price').length){

//		if($('input.maxCost').length, $('input.minCost').length){
//			$('input.maxCost').val(0);
//			$('input.minCost').val(0);
//		}

		$('.slider-price').each(function(){
			var el = $(this);
			el.slider({
				min: parseInt(el.attr('data-min')),
				max: parseInt(el.attr('data-max')),
				range: true,
				values: [0 ,0],
				step: parseInt(el.attr('data-step')),
				stop: function (event, ui) {
					el.closest('.price').find("input.minCost").val(el.slider("values", 0));
					el.closest('.price').find("input.maxCost").val(el.slider("values", 1));
				},
				slide: function (event, ui) {
					el.closest('.price').find("input.minCost").val(el.slider("values", 0));
					el.closest('.price').find("input.maxCost").val(el.slider("values", 1));
				}
			});
		});

		$("input.minCost").change(function () {
			var input1 = $(this).closest('.wrap').find("input.minCost").val();
			var input2 = $(this).closest('.wrap').find("input.maxCost").val();
			if (input1 > input2) {
				input1 = input2;
				input1();
			}
			$(this).closest('.price').find('.slider-price').slider("values", 0, input1);
		});

		$("input.maxCost").change(function () {
			var input1 = $(this).closest('.wrap').find('input.minCost').val();
			var input2 = $(this).closest('.wrap').find("input.maxCost").val();
			if (input1 > input2) {
				input2 = input1;
				input2();
			}
			$(this).closest('.price').find('.slider-price').slider("values", 1, input2);
		});
	}

	$(".check-input , .user-form input[type=checkbox]").Custom({
		customStyleClass: 'checkbox',
		customHeight: '17',
		enableHover: true
	});

	$(".user-form input[type=radio]").Custom({
		customStyleClass: 'checkbox',
		customHeight: '11',
		enableHover: true
	});

	$(document).on('click', '.popup .btn-close , .popup-product .btn-close, .deliver-and-pay .btn-close', function (e) {
		e.preventDefault();
		$.fancybox.close();
	});

	$('.product-list-top .turn').on('click', function (e) {
		e.preventDefault();
		$(this).closest('.drop-list').slideUp();
	});
	$("body").on("click", function (e) {
		if(!$(e.target).closest('.header-top').length){
			$('.header-top .search-block').slideUp();
		}
		if(!$(e.target).closest('.contact-info').length){
			$('header').removeClass('header-lvl');
			$('.instruction-city .sub-item').css('display', 'none');
			$('.instruction-city').stop(true, true).fadeOut(function () {
				$('.instruction-city .sub-item:first').stop(true, true).fadeIn();
			});
		}
	});

	$('.header-top .search-block .btn-close').on('click',function(e){
		e.preventDefault();
		$(this).closest('.search-block').slideUp();
	});

	$('.about-brand .slider ul').carouFredSel({
		items: 1,
		auto: true,
		timeoutDuration: 8,
		responsive: true,
		scroll: 1,
		swipe:{
			onTouch:true
		},
		prev: {
			key: 'left',
			button: function () {
				return $(this).closest('.slider').find('.btn-left')
			}
		},
		next: {
			key: 'right',
			button: function () {
				return $(this).closest('.slider').find('.btn-right')
			}
		},
		pagination: function () {
			return $(this).closest('.slider').find('.control-disk')
		}
	});

	var zoomItem = $(".product-zoom .zoom").elevateZoom({
		zoomType: "lens",
		lensShape: "round",
		lensBorder: 3,
		lensSize: 150,
		galleryActiveClass: 'active',
		imageCrossfade: true,
		gallery: 'gallery-zoom-product'
	});

	$('.comment-form .close').on('click', function (e) {
		e.preventDefault();
		$(this).closest('.comment-form').slideUp();
	});
	$('.comment-list .btn-beige').on('click', function (e) {
		e.preventDefault();
		$(this).closest('li').find('.comment-form').slideDown();
	});

	$('.current__tab ul li a').on('click', function (e) {
		e.preventDefault();
		$('.current__tab ul li').removeClass('active');
		var el = $(this).closest('li');
		el.addClass('active');
		var tab = $('.tab-info > ul > li').removeClass('active').hide().eq(el.index()).fadeIn().addClass('active');
		var show = tab.find('.zoom').length > 0;
		if (zoomItem.length) {
			zoomItem.data('elevateZoom').changeState(show);
			$('.zoomContainer').toggle(show);
		}
	});

	$('.order-table .row').on('click', function () {
		var $this = $(this);
		$this.toggleClass('active');
		$this.find('.drop-list').slideToggle();
	});
	var menuTimeout;
	$('.header-btm .menu li a').mouseenter(function (e) {
		e.preventDefault();
		clearTimeout(menuTimeout);
		if ($(this).hasClass('hover')) {
			return;
		}
		$('.header-btm .menu li a').removeClass('hover');
		$(this).addClass('hover');
		var elPosition = $(this).offset();
		var elEqual = $(this).closest('li');
		$('.sub-menu-list > ul > li.item').removeClass('active').hide().eq(elEqual.index()).fadeIn().addClass('active');
		$('.sub-menu-list').css('top', elPosition.top + 28).stop(true, true).slideDown();
	});
	$('.header-btm .menu li a').mouseleave(function(){
		clearTimeout(menuTimeout);
		menuTimeout = setTimeout(function () {
			$('.sub-menu-list').slideUp();
			$('.header-btm .menu li a').removeClass('hover');
		}, 50);
	});
	$('.sub-menu-list').mouseenter(function () {
		clearTimeout(menuTimeout);
	});
	$('.sub-menu-list').mouseleave(function () {
		clearTimeout(menuTimeout);
		var el = $(this);
		menuTimeout = setTimeout(function () {
			el.stop(true, true).slideUp();
			$('.header-btm .menu li a').removeClass('hover');
		}, 50);
	});
	$('.sub-menu-list .btn-close').on('click',function(){
		$('.sub-menu-list').slideUp();
		$('.header-btm .menu li a').removeClass('hover');
	});

	$('.wrap-select select').select2();

	$("#user-form").validate();
	$("#message-form").validate();
	$("#address-form").validate();
	$("#subscribe-form").validate({
		submitHandler: function (form) {
			$.fancybox.open({
				href: $(form).attr('action'),
				type: 'ajax',
				padding: 0,
				afterShow: function () {
					prepareFancyboxContent(this);
				}
			});
		}
	});

	$(document).on('mouseenter.elementhover', '.slider-catalog ul li', function(){
		$(this).addClass('active');
	}).on('mouseleave.elementhover', '.slider-catalog ul li', function(){
		$(this).removeClass('active');
	});

	$(document).on('mouseenter.elementhover', '.wrap-product', function(){
		$(this).addClass('active');
	}).on('mouseleave.elementhover', '.wrap-product', function(){
		$(this).removeClass('active');
	});
});

if ($('.wrap-map').length) {
//yandex map

	function init() {
		var map = new ymaps.Map("map", {
			center: [55.743650, 37.637192],
			zoom: 13,
			behaviors: ["zoomScroll",'drag']
		});

		var markers = [];
		function clearOverlays() {
			if (markers) {
				for (i in markers) {
					map.geoObjects.remove(markers[i]);
				}
			}
			markers = [];
		}

		$('#city-select').on('change', function () {
			clearOverlays();
			map.setCenter(locations[$(this).val()].center,13);
			$.each(locations[$(this).val()].list, function (key, el) {
				var marker = new ymaps.Placemark(el.coordinates, el.data, el.icon);
				markers.push(marker);
				map.geoObjects.add(marker);

				marker.events.add('mouseenter', function (e) {
					e.get('target').options.set('iconImageHref', el.iconactive);
				});
				marker.events.add('mouseleave', function (e) {
					e.get('target').options.set('iconImageHref', el.icon.iconImageHref);
				});
			});
		}).trigger('change');

		if ($('.wrap-map.contacts').length || $('.delivery-map').length) {
			var contactMarker = new ymaps.Placemark(
				contactCoordinates,
				{
					balloonImageOffset: [-200, 0]
				},
				{
					iconLayout: 'default#image',
					iconImageHref: 'img/marker-city.png',
					iconImageSize: [95, 119]
				}
			);
			map.geoObjects.add(contactMarker);
		}
        map.behaviors.disable('scrollZoom');

	}

	ymaps.ready(init);
}

